import base64
import json
import os
import time
import urllib.request
from urllib.parse import urlparse, unquote

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from utils.config import (
    AWS_REGION,
    BEDROCK_MODEL_ID,
    S3_AUDIO_BUCKET,
    S3_TTS_BUCKET,
    TRANSCRIBE_LANGUAGE_CODE,
    POLLY_VOICE_ID,
    TURN_SILENCE_SECONDS,
    SESSION_SILENCE_SECONDS,
)
from utils.session_audio_store import STORE

# ==========================================================
# Constants / Globals
# ==========================================================

GENERIC_ERR = "Something went wrong, Please try again"

s3 = boto3.client("s3", region_name=AWS_REGION)
transcribe = boto3.client("transcribe", region_name=AWS_REGION)
bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)
polly = boto3.client("polly", region_name=AWS_REGION)

# Preferred order — newer/better first; includes common ON_DEMAND options
_PREFERRED_ANTHROPIC = [
    # Newer (often profile-only) – kept here but we won't try to pass a profile ARN
    "anthropic.claude-sonnet-4-20250514-v1:0",
    "anthropic.claude-3-5-sonnet-20241022-v2:0",
    "anthropic.claude-opus-4-20250514-v1:0",
    "anthropic.claude-3-7-sonnet-20250219-v1:0",
    # On-demand models (most accounts can enable these in Model access)
    "anthropic.claude-3-5-sonnet-20240620-v1:0",
    "anthropic.claude-3-sonnet-20240229-v1:0",
    "anthropic.claude-3-haiku-20240307-v1:0",
    # Legacy v2 (different payload schema)
    "anthropic.claude-v2:1",
]

# ==========================================================
# S3 helpers
# ==========================================================

def _s3_put(bucket: str, key: str, data: bytes, content_type: str) -> str:
    s3.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    print(f"[s3_put] Uploaded {key} to {bucket}")
    return f"s3://{bucket}/{key}"

def _s3_presigned_get(bucket: str, key: str, expires: int = 3600) -> str:
    url = s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=expires,
    )
    print(f"[s3_get] presigned: {url}")
    return url

# ==========================================================
# Transcribe (batch) helper
# ==========================================================

def _transcribe_batch_wait(s3_uri: str, media_format: str) -> str:
    job_name = f"ai-ba-{int(time.time()*1000)}"
    print(f"[transcribe] start job={job_name} uri={s3_uri} fmt={media_format}")
    transcribe.start_transcription_job(
        TranscriptionJobName=job_name,
        Media={"MediaFileUri": s3_uri},
        MediaFormat=media_format,
        LanguageCode=TRANSCRIBE_LANGUAGE_CODE,
        OutputBucketName=S3_TTS_BUCKET,  # transcript json goes here (private)
    )

    while True:
        r = transcribe.get_transcription_job(TranscriptionJobName=job_name)
        st = r["TranscriptionJob"]["TranscriptionJobStatus"]
        print(f"[transcribe] status: {st}")
        if st == "COMPLETED":
            t_uri = r["TranscriptionJob"]["Transcript"]["TranscriptFileUri"]
            print(f"[transcribe] transcript uri: {t_uri}")
            try:
                u = urlparse(t_uri)
                path = unquote(u.path.lstrip("/"))
                bucket, key = path.split("/", 1)
                obj = s3.get_object(Bucket=bucket, Key=key)
                txt = obj["Body"].read().decode("utf-8")
            except Exception as e:
                print(f"[transcribe] fetch via SDK failed: {e}")
                try:
                    if "bucket" in locals() and "key" in locals():
                        url = s3.generate_presigned_url(
                            "get_object",
                            Params={"Bucket": bucket, "Key": key},
                            ExpiresIn=300,
                        )
                        txt = urllib.request.urlopen(url).read().decode("utf-8")
                    else:
                        return ""
                except Exception as e2:
                    print(f"[transcribe] fetch via presign failed: {e2}")
                    return ""

            try:
                obj_json = json.loads(txt)
                transcript = obj_json.get("results", {}).get("transcripts", [{}])[0].get("transcript", "")
                print(f"[transcribe] final transcript: {transcript}")
                return transcript
            except Exception as je:
                print(f"[transcribe] JSON parse failed: {je}")
                return ""
        if st == "FAILED":
            print(f"[transcribe] job failed: {r['TranscriptionJob'].get('FailureReason')}")
            return ""
        time.sleep(2)

# ==========================================================
# Conversation formatting for LLM
# ==========================================================

def _format_conversation(history, user_text: str) -> str:
    lines = []
    for t in history:
        # supports both dot and dict style depending on your STORE implementation
        u = getattr(t, "transcript", None) if hasattr(t, "transcript") else t.get("transcript")
        a = getattr(t, "response", None) if hasattr(t, "response") else t.get("response")
        if u:
            lines.append(f"User: {u}")
        if a:
            lines.append(f"Assistant: {a}")
    if user_text:
        lines.append(f"User: {user_text}")
    lines.append("Assistant:")
    return "\n".join(lines)

# ==========================================================
# Bedrock: model probing & selection (ON-DEMAND only)
# ==========================================================

def _is_v2_family(model_id: str) -> bool:
    return model_id.startswith("anthropic.claude-v2")

def _build_body(model_id: str, text_prompt: str) -> dict:
    # payload shape depends on family
    if _is_v2_family(model_id):
        return {
            "prompt": text_prompt,
            "max_tokens_to_sample": 500,
            "temperature": 0.6,
            "top_p": 1.0,
            "stop_sequences": ["\nUser:"],
        }
    return {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 256,
        "temperature": 0.6,
        "top_p": 1.0,
        "messages": [
            {"role": "user", "content": [{"type": "text", "text": text_prompt}]}
        ],
    }

def _parse_anthropic_response(model_id: str, raw: str) -> str:
    try:
        d = json.loads(raw)
    except Exception:
        return raw
    if _is_v2_family(model_id):
        return d.get("completion") or d.get("output_text") or raw
    for part in d.get("content", []):
        if part.get("type") == "text" and "text" in part:
            return part["text"]
    return d.get("output_text") or d.get("completion") or raw

def _probe_invoke_model(model_id: str) -> bool:
    """True if a tiny on-demand invoke works for model_id (with your current SDK)."""
    payload = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1,
        "messages": [{"role": "user", "content": [{"type": "text", "text": "ping"}]}],
    }
    try:
        r = bedrock.invoke_model(
            modelId=model_id,
            accept="application/json",
            contentType="application/json",
            body=json.dumps(payload),
        )
        _ = r["body"].read()
        print(f"[probe] {model_id}: OK")
        return True
    except Exception as e:
        print(f"[probe] {model_id}: DENIED ({e})")
        return False

def _discover_accessible_models() -> set:
    """Find Anthropic models in-region, then probe invoke to confirm ON-DEMAND access."""
    try:
        resp = bedrock.list_foundation_models()
        all_anthropic = [
            m["modelId"]
            for m in resp.get("modelSummaries", [])
            if m.get("providerName") == "Anthropic"
        ]
        print(f"[discover] Found {len(all_anthropic)} Anthropic models in region.")
    except Exception as e:
        print(f"[discover] list_foundation_models failed: {e}")
        all_anthropic = []

    accessible = set()
    for mid in all_anthropic:
        if _probe_invoke_model(mid):
            accessible.add(mid)

    print(f"[discover] Accessible on-demand models: {sorted(accessible)}")
    return accessible

ACCESSIBLE_MODELS = _discover_accessible_models()

def _select_active_model(configured: str) -> str:
    """
    Choose an active on-demand model:
      1) If configured model is accessible → use it.
      2) Else choose first accessible from preferred list.
      3) Else pick any accessible.
      4) Else return configured (invocations will fail; we catch and return GENERIC_ERR).
    """
    if configured in ACCESSIBLE_MODELS:
        print(f"[startup] Using configured on-demand model: {configured}")
        return configured
    for mid in _PREFERRED_ANTHROPIC:
        if mid in ACCESSIBLE_MODELS:
            print(f"[startup] Configured not accessible; using on-demand fallback: {mid}")
            return mid
    if ACCESSIBLE_MODELS:
        any_mid = sorted(list(ACCESSIBLE_MODELS))[0]
        print(f"[startup] No preferred match; using on-demand: {any_mid}")
        return any_mid
    print(f"[startup] No on-demand model access detected; will still run with configured: {configured}")
    return configured

ACTIVE_MODEL_ID = _select_active_model(BEDROCK_MODEL_ID)
print(f"[startup] AWS_REGION={AWS_REGION}, ACTIVE_MODEL_ID={ACTIVE_MODEL_ID}")

def _invoke_bedrock(body_json: str, model_id: str):
    """
    Invoke Anthropic model ON-DEMAND using modelId ONLY.
    (We intentionally do NOT pass inferenceProfileArn because your SDK rejects it.)
    """
    return bedrock.invoke_model(
        modelId=model_id,
        accept="application/json",
        contentType="application/json",
        body=body_json,
    )

def _try_bedrock_any(body_json: str, configured_model_id: str):
    errors = []

    # 1) Try configured/active
    try:
        return _invoke_bedrock(body_json, configured_model_id)
    except Exception as e:
        print(f"[bedrock] primary failed: {e}")
        errors.append(f"{configured_model_id}: {e}")

    # 2) Try accessible fallbacks in preferred order
    for mid in _PREFERRED_ANTHROPIC:
        if mid == configured_model_id or mid not in ACCESSIBLE_MODELS:
            continue
        try:
            print(f"[bedrock] trying fallback: {mid}")
            return _invoke_bedrock(body_json, mid)
        except Exception as e:
            print(f"[bedrock] fallback failed ({mid}): {e}")
            errors.append(f"{mid}: {e}")

    raise RuntimeError("Bedrock invoke failed; tried: " + " | ".join(errors))

def _bedrock_complete(history, user_text) -> str:
    print("[bedrock] start completion")
    try:
        convo = _format_conversation(history, user_text)
        system_preamble = (
            "You are a helpful business analyst assistant. "
            "Continue the conversation naturally, ask clarifying follow-ups if needed, "
            "and keep responses concise.\n\n"
        )
        text_prompt = system_preamble + convo

        # Build payload for the model family
        mid = ACTIVE_MODEL_ID or BEDROCK_MODEL_ID
        body = _build_body(mid, text_prompt)
        body_json = json.dumps(body)
        print(f"[bedrock] body size={len(body_json)} model={mid}")

        try:
            resp = _try_bedrock_any(body_json, mid)
        except Exception as e:
            print(f"[bedrock] invoke failed after fallbacks: {e}")
            return GENERIC_ERR

        raw = resp["body"].read().decode("utf-8")
        print(f"[bedrock] raw: {raw[:200]}...")
        out = _parse_anthropic_response(mid, raw)
        return out or GENERIC_ERR

    except (ClientError, BotoCoreError) as e:
        msg = getattr(e, "response", {}).get("Error", {}).get("Message", str(e))
        print(f"[bedrock] client error: {msg}")
        return GENERIC_ERR
    except Exception as e:
        print(f"[bedrock] unexpected error: {e}")
        return GENERIC_ERR

# ==========================================================
# Polly helper
# ==========================================================

def _polly_tts_url(text: str) -> str:
    try:
        if not text:
            return ""
        r = polly.synthesize_speech(VoiceId=POLLY_VOICE_ID, OutputFormat="mp3", Text=text)
        audio = r["AudioStream"].read()
        key = f"tts/{int(time.time()*1000)}.mp3"
        _s3_put(S3_TTS_BUCKET, key, audio, "audio/mpeg")
        url = _s3_presigned_get(S3_TTS_BUCKET, key)
        print(f"[polly] tts url: {url}")
        return url
    except Exception as e:
        print(f"[polly] error: {e}")
        return ""

# ==========================================================
# Public API used by FastAPI router
# ==========================================================

async def ai_ba_start():
    sid = STORE.create()
    print(f"[session] start sid={sid}")
    return {
        "session_id": sid,
        "turn_silence_seconds": TURN_SILENCE_SECONDS,
        "session_silence_seconds": SESSION_SILENCE_SECONDS,
    }

async def ai_ba_push_audio(session_id: str, audio_chunk_b64: str):
    if not STORE.is_open(session_id):
        return {"error": "session_closed"}
    try:
        data = base64.b64decode(audio_chunk_b64)
    except Exception:
        print("[push] invalid base64 chunk")
        return {"error": "invalid_audio_chunk"}
    STORE.push(session_id, data)
    print(f"[push] ok len={len(data)} sid={session_id}")
    return {"ok": True}

async def ai_ba_turn(session_id: str):
    if not STORE.is_open(session_id):
        return {"error": "session_closed"}
    try:
        audio = STORE.consume_turn(session_id)
        if not audio:
            print("[turn] no audio buffered")
            return {"session_id": session_id, "transcript": "", "response": "", "tts_url": ""}

        audio_key = f"audio/{session_id}-{int(time.time()*1000)}.webm"
        s3_uri = _s3_put(S3_AUDIO_BUCKET, audio_key, audio, "audio/webm")

        transcript = _transcribe_batch_wait(s3_uri, "webm")
        if not transcript:
            print("[turn] empty transcript")
            response = GENERIC_ERR
            tts_url = _polly_tts_url(response)
            STORE.append_turn(session_id, "", response, tts_url)
            return {
                "session_id": session_id,
                "transcript": "",
                "response": response,
                "tts_url": tts_url,
                "audio_s3_uri": s3_uri,
            }

        response = _bedrock_complete(STORE.sessions[session_id].history, transcript)
        if not response or response.startswith("(Bedrock error"):
            response = GENERIC_ERR
        tts_url = _polly_tts_url(response)

        STORE.append_turn(session_id, transcript, response, tts_url)
        return {
            "session_id": session_id,
            "transcript": transcript,
            "response": response,
            "tts_url": tts_url,
            "audio_s3_uri": s3_uri,
        }
    except Exception as e:
        print(f"[turn] unexpected: {e}")
        return {"session_id": session_id, "transcript": "", "response": GENERIC_ERR, "tts_url": ""}

async def ai_ba_ping(session_id: str):
    try:
        if STORE.is_open(session_id) and STORE.age(session_id) >= SESSION_SILENCE_SECONDS:
            print(f"[ping] session {session_id} exceeded silence; stopping")
            return await ai_ba_stop(session_id=session_id)
        return {"waiting": True}
    except Exception as e:
        print(f"[ping] error: {e}")
        return {"waiting": False}

async def ai_ba_stop(session_id: str):
    # snapshot BEFORE closing
    sess = STORE.sessions.get(session_id)
    history_snapshot = list(sess.history) if sess else []
    audio = STORE.close(session_id)

    transcript = ""
    response = ""
    tts_url = ""

    try:
        if audio:
            audio_key = f"audio/{session_id}-final.webm"
            try:
                s3_uri = _s3_put(S3_AUDIO_BUCKET, audio_key, audio, "audio/webm")
            except Exception as e:
                print(f"[stop] S3 put failed: {e}")
                s3_uri = None

            if s3_uri:
                try:
                    transcript = _transcribe_batch_wait(s3_uri, "webm")
                    print(f"[stop] transcript: {transcript}")
                except Exception as e:
                    print(f"[stop] transcribe failed: {e}")
                    transcript = ""

            if transcript:
                try:
                    response = _bedrock_complete(history_snapshot, transcript)
                except Exception as e:
                    print(f"[stop] bedrock failed: {e}")
                    response = GENERIC_ERR

            if response:
                try:
                    if response.startswith("(Bedrock error"):
                        response = GENERIC_ERR
                    tts_url = _polly_tts_url(response)
                except Exception as e:
                    print(f"[stop] polly failed: {e}")
                    tts_url = ""
    except Exception as e:
        print(f"[stop] unexpected: {e}")

    return {
        "session_id": session_id,
        "transcript": transcript,
        "response": response,
        "tts_url": tts_url,
        "history": [
            {"transcript": t.transcript, "response": t.response, "tts_url": t.tts_url}
            for t in history_snapshot
        ],
    }