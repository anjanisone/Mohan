
import os
from dotenv import load_dotenv
load_dotenv()

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
BEDROCK_MODEL_ID = "arn:aws:bedrock:us-east-1:125396563242:application-inference-profile/n4gmm4bwm1u4"
S3_AUDIO_BUCKET = os.getenv("S3_AUDIO_BUCKET", "poc-conversation-input-125396563242-ea97e9")
S3_TTS_BUCKET = os.getenv("S3_TTS_BUCKET", "poc-conversation-output-125396563242-ea97e9")
TRANSCRIBE_LANGUAGE_CODE = os.getenv("TRANSCRIBE_LANGUAGE_CODE", "en-US")
POLLY_VOICE_ID = os.getenv("POLLY_VOICE_ID", "Joanna")
TURN_SILENCE_SECONDS = int(os.getenv("TURN_SILENCE_SECONDS", "2"))
SESSION_SILENCE_SECONDS = int(os.getenv("SESSION_SILENCE_SECONDS", "20"))
#BEDROCK_INFERENCE_PROFILE_ARN = "arn:aws:bedrock:us-east-1:593110852504:inference-profile/us.anthropic.claude-3-sonnet-20240229-v1:0"

BEDROCK_INFERENCE_PROFILE_ARN = "arn:aws:bedrock:us-east-1:125396563242:application-inference-profile/n4gmm4bwm1u4"