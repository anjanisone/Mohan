
const chat = document.getElementById('chat')
const startBtn = document.getElementById('start')
const stopBtn = document.getElementById('stop')
const ttsEl = document.getElementById('tts')
const bubbleTpl = document.getElementById('bubble-template')
const typingTpl = document.getElementById('typing-template')

let sessionId = null
let mediaRecorder = null
let pushing = false
let thinkingEl = null
let pingTimer = null
let analyser = null
let audioCtx = null
let micSource = null
let silenceMs = 0
let turnSilenceMs = 1200
let sessionSilenceMs = 20000

function nowTime() {
  const d = new Date()
  return d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})
}

function scrollBottom() { chat.scrollTop = chat.scrollHeight }

function addBubble(role, text) {
  const node = bubbleTpl.content.firstElementChild.cloneNode(true)
  node.classList.add(role === 'user' ? 'user' : 'bot')
  node.querySelector('.who').textContent = role === 'user' ? 'You' : 'Assistant'
  node.querySelector('.time').textContent = nowTime()
  node.querySelector('.text').textContent = text
  chat.appendChild(node)
  scrollBottom()
  return node
}

function showThinking() {
  removeThinking()
  thinkingEl = typingTpl.content.firstElementChild.cloneNode(true)
  thinkingEl.querySelector('.time').textContent = nowTime()
  chat.appendChild(thinkingEl)
  scrollBottom()
}

function removeThinking() {
  if (thinkingEl && thinkingEl.parentNode) thinkingEl.parentNode.removeChild(thinkingEl)
  thinkingEl = null
}

async function startSession() {
  const r = await fetch('/ai-ba/start', { method: 'POST' })
  const j = await r.json()
  sessionId = j.session_id
  if (j.turn_silence_seconds) turnSilenceMs = j.turn_silence_seconds * 1000
  if (j.session_silence_seconds) sessionSilenceMs = j.session_silence_seconds * 1000
}

async function pushChunk(ab) {
  if (!sessionId) return
  const b64 = btoa(String.fromCharCode(...new Uint8Array(ab)))
  await fetch('/ai-ba/push', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ session_id: sessionId, audio_chunk_b64: b64 })
  })
}

async function finalizeTurn() {
  if (!sessionId) return
  pushing = false
  if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop()
  showThinking()
  const r = await fetch('/ai-ba/turn', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ session_id: sessionId })
  })
  const j = await r.json()
  removeThinking()
  if (j.transcript && j.transcript.trim().length) addBubble('user', j.transcript.trim())
  if (j.response && j.response.trim().length) addBubble('bot', j.response.trim())
  if (j.tts_url) { ttsEl.src = j.tts_url; ttsEl.play().catch(()=>{}) }
  await resumeRecorder()
}

async function stopSession(finalize = true) {
  if (!sessionId) return
  const r = await fetch('/ai-ba/stop', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ session_id: sessionId })
  })
  const j = await r.json()
  if (finalize) {
    if (j.transcript && j.transcript.trim().length) addBubble('user', j.transcript.trim())
    if (j.response && j.response.trim().length) addBubble('bot', j.response.trim())
    if (j.tts_url) { ttsEl.src = j.tts_url; ttsEl.play().catch(()=>{}) }
  }
  sessionId = null
  startBtn.disabled = false
  stopBtn.disabled = true
  if (pingTimer) clearInterval(pingTimer)
}

async function handleSilencePing() {
  if (!sessionId) return
  const r = await fetch('/ai-ba/ping', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ session_id: sessionId })
  })
  const j = await r.json()
  if (j && (j.transcript || j.response || j.tts_url || j.history)) {
    await stopSession(false)
  }
}

function setupSilenceDetection(stream) {
  audioCtx = new (window.AudioContext || window.webkitAudioContext)()
  micSource = audioCtx.createMediaStreamSource(stream)
  analyser = audioCtx.createAnalyser()
  analyser.fftSize = 2048
  micSource.connect(analyser)

  const buf = new Float32Array(analyser.fftSize)
  const threshold = 0.01

  function loop() {
    if (!analyser) return
    analyser.getFloatTimeDomainData(buf)
    let rms = 0
    for (let i = 0; i < buf.length; i++) rms += buf[i]*buf[i]
    rms = Math.sqrt(rms / buf.length)
    const silent = rms < threshold
    if (silent) {
      silenceMs += 100
      if (silenceMs > sessionSilenceMs && sessionId) {
        stopBtn.click()
        return
      }
      if (silenceMs > turnSilenceMs && pushing) {
        finalizeTurn()
        silenceMs = 0
        return
      }
    } else {
      silenceMs = 0
    }
    setTimeout(loop, 100)
  }
  loop()
}

async function resumeRecorder() {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
  mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' })
  pushing = true
  mediaRecorder.ondataavailable = async (e) => {
    if (!pushing || e.data.size === 0) return
    const ab = await e.data.arrayBuffer()
    await pushChunk(ab)
  }
  mediaRecorder.start(700)
  setupSilenceDetection(stream)
}

startBtn.onclick = async () => {
  await startSession()
  addBubble('bot', 'Listening… Speak your requirement.')
  await resumeRecorder()
  startBtn.disabled = true
  stopBtn.disabled = false
  if (pingTimer) clearInterval(pingTimer)
  pingTimer = setInterval(handleSilencePing, 4000)
}

stopBtn.onclick = async () => {
  pushing = false
  if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop()
  showThinking()
  await stopSession(true)
  removeThinking()
}
