# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from agent.fastapi_endpoint import router

app = FastAPI(title="VA BA Conversational Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


#    Adjust the path to your actual frontend folder
app.mount("/ui", StaticFiles(directory="./frontend", html=True), name="frontend")

@app.get("/")
def _root():
    return RedirectResponse(url="/ui/")