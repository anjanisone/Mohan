
import time, threading
from dataclasses import dataclass, field
from typing import Dict, List

@dataclass
class Turn:
    transcript: str
    response: str
    tts_url: str

@dataclass
class Session:
    created_at: float = field(default_factory=lambda: time.time())
    last_active: float = field(default_factory=lambda: time.time())
    buffer: bytearray = field(default_factory=bytearray)
    open: bool = True
    history: List[Turn] = field(default_factory=list)

class SessionStore:
    def __init__(self):
        self._lock = threading.Lock()
        self._seq = 0
        self.sessions: Dict[str, Session] = {}

    def create(self) -> str:
        with self._lock:
            self._seq += 1
            sid = f"s{int(time.time()*1000)}_{self._seq}"
            self.sessions[sid] = Session()
            return sid

    def is_open(self, sid: str) -> bool:
        s = self.sessions.get(sid)
        return bool(s and s.open)

    def push(self, sid: str, data: bytes) -> None:
        s = self.sessions.get(sid)
        if not s or not s.open:
            return
        s.buffer.extend(data)
        s.last_active = time.time()

    def age(self, sid: str) -> float:
        s = self.sessions.get(sid)
        if not s:
            return 0.0
        return time.time() - s.last_active

    def consume_turn(self, sid: str) -> bytes:
        s = self.sessions.get(sid)
        if not s or not s.open:
            return b""
        data = bytes(s.buffer)
        s.buffer.clear()
        s.last_active = time.time()
        return data

    def append_turn(self, sid: str, transcript: str, response: str, tts_url: str) -> None:
        s = self.sessions.get(sid)
        if not s:
            return
        s.history.append(Turn(transcript=transcript, response=response, tts_url=tts_url))

    def close(self, sid: str) -> bytes:
        s = self.sessions.get(sid)
        if not s:
            return b""
        s.open = False
        data = bytes(s.buffer)
        s.buffer.clear()
        return data

STORE = SessionStore()
