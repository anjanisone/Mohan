
from fastapi import APIRouter, Request, HTTPException
from typing import Any, Dict
from mcp_servers_ds_api_tools.virtual_assistant_ba_tool import (
    ai_ba_start, ai_ba_push_audio, ai_ba_turn, ai_ba_ping, ai_ba_stop
)
router = APIRouter()

@router.get("/health")
async def health() -> Dict[str, Any]:
    return {"ok": True}

@router.post("/ai-ba/start")
async def start() -> Dict[str, Any]:
    try:
        return await ai_ba_start()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/ai-ba/push")
async def push(req: Request) -> Dict[str, Any]:
    try:
        p = await req.json()
        return await ai_ba_push_audio(session_id=p["session_id"], audio_chunk_b64=p["audio_chunk_b64"])
    except KeyError as ke:
        raise HTTPException(status_code=400, detail=f"Missing field: {ke}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/ai-ba/turn")
async def turn(req: Request) -> Dict[str, Any]:
    try:
        p = await req.json()
        return await ai_ba_turn(session_id=p["session_id"])
    except KeyError as ke:
        raise HTTPException(status_code=400, detail=f"Missing field: {ke}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/ai-ba/ping")
async def ping(req: Request) -> Dict[str, Any]:
    try:
        p = await req.json()
        return await ai_ba_ping(session_id=p["session_id"])
    except KeyError as ke:
        raise HTTPException(status_code=400, detail=f"Missing field: {ke}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/ai-ba/stop")
async def stop(req: Request) -> Dict[str, Any]:
    try:
        p = await req.json()
        return await ai_ba_stop(session_id=p["session_id"])
    except KeyError as ke:
        raise HTTPException(status_code=400, detail=f"Missing field: {ke}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
