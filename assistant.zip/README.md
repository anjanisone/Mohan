
# Voice-Based AI Business Analyst – Conversational (AWS)
Multi‑turn voice chat using Amazon Transcribe (batch), Bedrock, and Polly. Ends on 20s silence or Stop.

## Run
```bash
pip install -r va_ba_conversation_app/requirements.txt
uvicorn va_ba_conversation_app.main:app --host 0.0.0.0 --port 8000
```
Create `.env` inside `va_ba_conversation_app/`:
```
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=anthropic.claude-3-sonnet-20240229-v1:0
S3_AUDIO_BUCKET=poc-conversation-input-<your-suffix>
S3_TTS_BUCKET=poc-conversation-output-<your-suffix>
TRANSCRIBE_LANGUAGE_CODE=en-US
POLLY_VOICE_ID=Joanna
TURN_SILENCE_SECONDS=2
SESSION_SILENCE_SECONDS=20
```
Use the buckets printed by your setup script.
